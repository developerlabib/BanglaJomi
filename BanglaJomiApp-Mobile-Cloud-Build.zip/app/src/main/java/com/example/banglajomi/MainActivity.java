package com.example.banglajomi;

import android.app.*;
import android.os.Bundle;
import android.graphics.*;
import android.graphics.pdf.PdfDocument;
import android.content.*;
import android.view.*;
import android.view.inputmethod.InputMethodManager;
import android.widget.*;
import org.json.*;
import java.io.*;
import java.text.DecimalFormat;
import java.util.*;

public class MainActivity extends Activity {
    LinearLayout root, ownersBox, plotsBox;
    EditText district, upazila, mouza, khatian, ownerName, ownerShare, dagNo, dagArea;
    TextView totals;
    ArrayList<Owner> owners = new ArrayList<>();
    ArrayList<Plot> plots = new ArrayList<>();
    final String PREF="jomi_data";
    int green=Color.rgb(20,94,45), navy=Color.rgb(8,48,88);
    static class Owner { String name; double share; Owner(String n,double s){name=n;share=s;} }
    static class Plot { String no; double area; Plot(String n,double a){no=n;area=a;} }
    @Override public void onCreate(Bundle b){super.onCreate(b); buildUI(); loadData(); renderLists(); updateTotals();}
    int dp(float n){return (int)(n*getResources().getDisplayMetrics().density+.5f);}
    TextView text(String s,int size,int color){TextView t=new TextView(this);t.setText(s);t.setTextSize(size);t.setTextColor(color);t.setPadding(dp(4),dp(6),dp(4),dp(6));return t;}
    EditText edit(String hint){EditText e=new EditText(this);e.setSingleLine(true);e.setTextSize(14);e.setHint(hint);e.setPadding(dp(12),dp(7),dp(12),dp(7));e.setBackgroundTintList(android.content.res.ColorStateList.valueOf(0xff9eada5));return e;}
    LinearLayout section(String title){LinearLayout box=new LinearLayout(this);box.setOrientation(1);box.setPadding(dp(12),dp(10),dp(12),dp(10));box.setBackgroundColor(Color.WHITE);LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,-2);p.setMargins(dp(10),dp(7),dp(10),dp(7));root.addView(box,p);TextView h=text(title,17,green);h.setTypeface(null,1);box.addView(h);return box;}
    Button button(String s,int color,Runnable r){Button b=new Button(this);b.setText(s);b.setTextColor(Color.WHITE);b.setBackgroundTintList(android.content.res.ColorStateList.valueOf(color));b.setOnClickListener(v->r.run());return b;}
    void buildUI(){
        ScrollView scroll=new ScrollView(this);scroll.setBackgroundColor(0xfff1f5f3);setContentView(scroll);
        root=new LinearLayout(this);root.setOrientation(1);scroll.addView(root);
        TextView head=text("জমির মালিকানা ও খতিয়ান",22,Color.WHITE);head.setGravity(Gravity.CENTER);head.setTypeface(null,1);head.setBackgroundColor(green);head.setPadding(0,dp(20),0,dp(20));root.addView(head);
        LinearLayout info=section("১. খতিয়ানের মৌলিক তথ্য");
        district=edit("জেলা");upazila=edit("উপজেলা");mouza=edit("মৌজা");khatian=edit("খতিয়ান নম্বর");
        info.addView(district);info.addView(upazila);info.addView(mouza);info.addView(khatian);
        LinearLayout plot=section("২. দাগ ও জমির পরিমাণ (শতক)");
        dagNo=edit("দাগ নম্বর");dagArea=edit("দাগের জমি (শতক)");plot.addView(dagNo);plot.addView(dagArea);
        plot.addView(button("＋ দাগ যোগ করুন",navy,()->addPlot()));
        plotsBox=new LinearLayout(this);plotsBox.setOrientation(1);plot.addView(plotsBox);
        LinearLayout own=section("৩. মালিক ও হিস্যা");
        ownerName=edit("মালিকের নাম");ownerShare=edit("হিস্যা (যেমন 171.88 / 1000)");own.addView(ownerName);own.addView(ownerShare);
        own.addView(button("＋ মালিক যোগ করুন",navy,()->addOwner()));
        ownersBox=new LinearLayout(this);ownersBox.setOrientation(1);own.addView(ownersBox);
        LinearLayout sum=section("৪. স্বয়ংক্রিয় হিসাব");
        totals=text("",15,green);sum.addView(totals);
        LinearLayout actions=section("৫. সংরক্ষণ ও রিপোর্ট");
        actions.addView(button("তথ্য সংরক্ষণ করুন",green,()->saveData()));
        actions.addView(button("PDF রিপোর্ট তৈরি করুন",navy,()->makePdf()));
        actions.addView(button("সব তথ্য মুছুন",0xffb3261e,()->new AlertDialog.Builder(this).setTitle("সব তথ্য মুছবেন?").setMessage("এই মোবাইলে সংরক্ষিত তথ্য মুছে যাবে।").setNegativeButton("না",null).setPositiveButton("মুছুন",(d,w)->clearAll()).show()));
        root.setPadding(0,0,0,dp(18));
    }
    void addPlot(){
        String n=dagNo.getText().toString().trim();double a=num(dagArea.getText().toString());
        if(n.isEmpty()||a<=0){toast("দাগ নম্বর ও সঠিক জমির পরিমাণ দিন");return;}
        plots.add(new Plot(n,a));dagNo.setText("");dagArea.setText("");renderLists();updateTotals();saveData(false);
    }
    void addOwner(){
        String n=ownerName.getText().toString().trim();double s=num(ownerShare.getText().toString());
        if(n.isEmpty()||s<=0){toast("মালিকের নাম ও হিস্যা দিন");return;}
        owners.add(new Owner(n,s));ownerName.setText("");ownerShare.setText("");renderLists();updateTotals();saveData(false);
    }
    double num(String s){try{return Double.parseDouble(s.trim().replace(",",""));}catch(Exception e){return 0;}}
    String fmt(double d){return new DecimalFormat("0.##").format(d);}
    void renderLists(){
        if(ownersBox==null)return;ownersBox.removeAllViews();plotsBox.removeAllViews();
        for(int i=0;i<plots.size();i++){final int ix=i;Plot p=plots.get(i);LinearLayout row=new LinearLayout(this);row.setGravity(Gravity.CENTER_VERTICAL);row.addView(text("দাগ "+p.no+"  •  "+fmt(p.area)+" শতক",14,Color.DKGRAY),new LinearLayout.LayoutParams(0,-2,1));Button del=new Button(this);del.setText("মুছুন");del.setOnClickListener(v->{plots.remove(ix);renderLists();updateTotals();saveData(false);});row.addView(del);plotsBox.addView(row);}
        for(int i=0;i<owners.size();i++){final int ix=i;Owner o=owners.get(i);LinearLayout row=new LinearLayout(this);row.setGravity(Gravity.CENTER_VERTICAL);row.addView(text(o.name+"\nহিস্যা: "+fmt(o.share)+" / 1000",14,Color.DKGRAY),new LinearLayout.LayoutParams(0,-2,1));Button del=new Button(this);del.setText("মুছুন");del.setOnClickListener(v->{owners.remove(ix);renderLists();updateTotals();saveData(false);});row.addView(del);ownersBox.addView(row);}
    }
    void updateTotals(){
        if(totals==null)return;double area=0,share=0;for(Plot p:plots)area+=p.area;for(Owner o:owners)share+=o.share;
        StringBuilder s=new StringBuilder("মোট দাগ: "+plots.size()+" টি\nমোট জমি: "+fmt(area)+" শতক\nমোট মালিক: "+owners.size()+" জন\nমালিকদের মোট হিস্যা: "+fmt(share)+" / 1000\n\nমালিকভিত্তিক আনুমানিক জমি:\n");
        for(Owner o:owners)s.append("• ").append(o.name).append(": ").append(fmt(area*o.share/1000.0)).append(" শতক\n");
        if(share>1000.0001)s.append("\n⚠ হিস্যার যোগফল ১০০০-এর বেশি। যাচাই করুন।");
        else if(share>0&&Math.abs(share-1000)>0.01)s.append("\nনোট: হিস্যার যোগফল ১০০০ নয়। তথ্য যাচাই করুন।");
        totals.setText(s.toString());
    }
    JSONObject data(){JSONObject j=new JSONObject();try{j.put("district",district.getText().toString());j.put("upazila",upazila.getText().toString());j.put("mouza",mouza.getText().toString());j.put("khatian",khatian.getText().toString());JSONArray a=new JSONArray();for(Owner o:owners){JSONObject x=new JSONObject();x.put("name",o.name);x.put("share",o.share);a.put(x);}j.put("owners",a);JSONArray p=new JSONArray();for(Plot x:plots){JSONObject z=new JSONObject();z.put("no",x.no);z.put("area",x.area);p.put(z);}j.put("plots",p);}catch(Exception ignored){}return j;}
    void saveData(){saveData(true);} void saveData(boolean msg){getSharedPreferences(PREF,0).edit().putString("data",data().toString()).apply();if(msg)toast("তথ্য এই মোবাইলে সংরক্ষণ হয়েছে");}
    void loadData(){try{String raw=getSharedPreferences(PREF,0).getString("data",null);if(raw==null)return;JSONObject j=new JSONObject(raw);district.setText(j.optString("district"));upazila.setText(j.optString("upazila"));mouza.setText(j.optString("mouza"));khatian.setText(j.optString("khatian"));JSONArray a=j.optJSONArray("owners");if(a!=null)for(int i=0;i<a.length();i++){JSONObject x=a.getJSONObject(i);owners.add(new Owner(x.optString("name"),x.optDouble("share")));}JSONArray p=j.optJSONArray("plots");if(p!=null)for(int i=0;i<p.length();i++){JSONObject x=p.getJSONObject(i);plots.add(new Plot(x.optString("no"),x.optDouble("area")));}}catch(Exception ignored){}}
    void clearAll(){owners.clear();plots.clear();district.setText("");upazila.setText("");mouza.setText("");khatian.setText("");getSharedPreferences(PREF,0).edit().clear().apply();renderLists();updateTotals();toast("তথ্য মুছে ফেলা হয়েছে");}
    void makePdf(){
        saveData(false);PdfDocument doc=new PdfDocument();Paint paint=new Paint(3);PdfDocument.PageInfo pi=new PdfDocument.PageInfo.Builder(595,842,1).create();PdfDocument.Page page=doc.startPage(pi);Canvas c=page.getCanvas();c.drawColor(Color.WHITE);
        paint.setColor(green);paint.setTextSize(20);paint.setTypeface(Typeface.create("sans-serif",Typeface.BOLD));c.drawText("জমির মালিকানা ও খতিয়ান বিবরণী",40,48,paint);
        paint.setColor(Color.DKGRAY);paint.setTextSize(12);paint.setTypeface(Typeface.create("sans-serif",Typeface.NORMAL));
        int y=82;c.drawText("জেলা: "+district.getText()+"    উপজেলা: "+upazila.getText(),40,y,paint);y+=22;c.drawText("মৌজা: "+mouza.getText()+"    খতিয়ান নং: "+khatian.getText(),40,y,paint);y+=32;
        paint.setColor(green);c.drawText("দাগের বিবরণ",40,y,paint);y+=20;paint.setColor(Color.DKGRAY);
        double total=0;for(Plot p:plots){if(y>760){break;}c.drawText("দাগ নং "+p.no+"  |  "+fmt(p.area)+" শতক",45,y,paint);y+=19;total+=p.area;}
        y+=15;paint.setColor(green);c.drawText("মালিক ও হিস্যা",40,y,paint);y+=22;paint.setColor(Color.DKGRAY);
        for(Owner o:owners){if(y>760)break;c.drawText(o.name+"  |  হিস্যা "+fmt(o.share)+"/1000  |  আনুমানিক "+fmt(total*o.share/1000)+" শতক",45,y,paint);y+=20;}
        y=Math.min(y+20,790);paint.setColor(Color.GRAY);paint.setTextSize(9);c.drawText("এই রিপোর্ট ব্যবহারকারীর দেওয়া তথ্যের ভিত্তিতে তৈরি। এটি সরকারি খতিয়ান বা মালিকানার প্রমাণপত্র নয়।",40,y,paint);
        doc.finishPage(page);
        try{File f=new File(getExternalFilesDir(null),"Jomi_Report.pdf");FileOutputStream out=new FileOutputStream(f);doc.writeTo(out);out.close();doc.close();android.net.Uri uri=androidx.core.content.FileProvider.getUriForFile(this,"com.example.banglajomi.provider",f);Intent i=new Intent(Intent.ACTION_SEND);i.setType("application/pdf");i.putExtra(Intent.EXTRA_STREAM,uri);i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);i.setClipData(android.content.ClipData.newUri(getContentResolver(),"PDF",uri));startActivity(Intent.createChooser(i,"PDF শেয়ার করুন"));}catch(Exception e){doc.close();toast("PDF তৈরি করা যায়নি: "+e.getMessage());}
    }
    void toast(String s){Toast.makeText(this,s,Toast.LENGTH_LONG).show();}
}
